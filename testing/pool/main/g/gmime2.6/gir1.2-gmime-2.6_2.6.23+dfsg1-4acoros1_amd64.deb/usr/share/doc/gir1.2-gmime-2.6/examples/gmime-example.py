#!/usr/bin/env python3

# example python code using GMime via GObject Introspection

# Author: Daniel Kahn Gillmor <dkg@fifthhorseman.net>
# License: GPL-3+

import gi
gi.require_version('GMime', '2.6')
from gi.repository import GMime
GMime.init(0)

f = GMime.StreamFile.new_for_path('/usr/share/doc/gir1.2-gmime-2.6/examples/example.eml', 'r')
parser = GMime.Parser.new_with_stream(f)
msg = parser.construct_message()

print("Subject is:", msg.subject)
