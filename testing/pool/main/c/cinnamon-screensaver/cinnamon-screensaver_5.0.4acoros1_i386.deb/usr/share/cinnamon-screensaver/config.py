# Generated file - DO NOT EDIT.  Edit config.py.in instead.

prefix="/usr"
datadir="/usr/share"
localedir=datadir+"/locale"
pkgdatadir="/usr/share/cinnamon-screensaver"
libdir="/usr/lib/i386-linux-gnu"
libexecdir="/usr/lib/i386-linux-gnu/cinnamon-screensaver"
PACKAGE="cinnamon-screensaver"
VERSION="5.0.4"
GETTEXT_PACKAGE="cinnamon-screensaver"
