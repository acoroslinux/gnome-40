__all__ = [ "os", "GSettingsWidgets", "SettingsWidgets" ]

__version__ = "1.8.0"
